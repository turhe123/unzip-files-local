Lakeside cabin trip, summer 2026

Notes from our week at the (fictional) Pinecrest Lake cabin.
- Day 1: arrived late, pizza by the fire
- Day 2: canoe to the island
- Day 3: rain, board games all afternoon
- Day 4: hike to the lookout
