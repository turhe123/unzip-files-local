Sample archive readme
This archive is used to test the unzip tool.
Line three of the readme.
