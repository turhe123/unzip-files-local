Fictional archive for tests.
